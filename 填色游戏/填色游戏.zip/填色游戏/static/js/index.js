const canvas = document.getElementById('my_canvas');
const canvasContext = canvas.getContext('2d', {
    willReadFrequently: true
});
const mediaQuery = window.matchMedia('(max-width: 1720px) and (max-height: 950px)');
const paletteImage = document.getElementById('palette');
const paletteCanvas = document.getElementById('palette_canvas');
const paletteContext = paletteCanvas.getContext('2d');
const sourceImage = new Image();
let sourceImageUrl = '';
let isFilling = false;

function compressImageData(imageData, width, height) {
    const palette = new Set()
    const pixels = []
    
    for (let i = 0; i < imageData.data.length; i += 4) {
        const isTransparent = imageData.data[i + 3] < 127;
        const color = isTransparent ? 
            [255, 255, 255] : 
            [
                imageData.data[i],
                imageData.data[i + 1],
                imageData.data[i + 2]
            ];
        const colorKey = JSON.stringify(color);
        palette.add(colorKey);
        pixels.push(colorKey);
    }
    
    const paletteArray = Array.from(palette).map(c => JSON.parse(c));
    const colorToIndex = new Map(paletteArray.map((color, index) => [JSON.stringify(color), index]));
    const indexedPixels = pixels.map(color => colorToIndex.get(color));
    
    return compressPixels(indexedPixels, paletteArray);
}

function compressPixels(pixels, palette) {
    if (!pixels.length) return { palette, pixels: [] };
    
    const compressed = [];
    let currentIndex = pixels[0];
    let count = 1;
    
    for (let i = 1; i < pixels.length; i++) {
        if (pixels[i] === currentIndex) {
            count++;
        } else {
            compressed.push([currentIndex, count]);
            currentIndex = pixels[i];
            count = 1;
        }
    }
    compressed.push([currentIndex, count]);
    
    return { palette, pixels: compressed };
}

function decompressImageData(result, width, height) {
    const { palette, pixels } = result;
    const imageData = canvasContext.createImageData(width, height);
    let position = 0;
    
    pixels.forEach(([colorIndex, count]) => {
        const color = palette[colorIndex];
        while (count > 0) {
            const dataIndex = position * 4;
            imageData.data[dataIndex] = color[0];     // r
            imageData.data[dataIndex + 1] = color[1]; // g
            imageData.data[dataIndex + 2] = color[2]; // b
            imageData.data[dataIndex + 3] = 255;      // a 始终设置为不透明
            position++;
            count--;
        }
    });
    
    return imageData;
}

$('.pic-box img').click(function () {
    sourceImageUrl = $(this).attr('src')
    sourceImage.src = sourceImageUrl
    $('.choose-pic').css('display', 'none')
    $('.control').css('display', 'flex')
});

sourceImage.onload = function () {
    function resizeAndDrawImage() {
        const scaleFactor = mediaQuery.matches ? 1 : 1.25;
        canvas.width = mediaQuery.matches ? 400 : 500;
        canvas.height = mediaQuery.matches ? 400 : 500;

        const scaledWidth = sourceImage.width * scaleFactor;
        const scaledHeight = sourceImage.height * scaleFactor;
        const positionX = (canvas.width - scaledWidth) / 2;
        const positionY = (canvas.height - scaledHeight) / 2;
        
        canvasContext.clearRect(0, 0, canvas.width, canvas.height);
        canvasContext.drawImage(sourceImage, positionX, positionY, scaledWidth, scaledHeight);
    }
    resizeAndDrawImage();
    resizeAndDrawPalette();
}

function resizeAndDrawPalette() {
    const scale = mediaQuery.matches ? 0.6 : 1;
    paletteCanvas.width = mediaQuery.matches ? 200 : 259;
    paletteCanvas.height = mediaQuery.matches ? 200 : 259;
    
    const paletteWidth = paletteImage.width * scale;
    const paletteHeight = paletteImage.height * scale;
    const positionX = (paletteCanvas.width - paletteWidth) / 2;
    const positionY = (paletteCanvas.height - paletteHeight) / 2;
    
    paletteContext.clearRect(0, 0, paletteCanvas.width, paletteCanvas.height);
    paletteContext.drawImage(paletteImage, positionX, positionY, paletteWidth, paletteHeight);
}

window.addEventListener('resize', resizeAndDrawPalette);

let currentColor = [255, 255, 255];

paletteCanvas.onclick = function (event) {
    const pixelData = paletteContext.getImageData(event.offsetX, event.offsetY, 1, 1).data;
    currentColor = [pixelData[0], pixelData[1], pixelData[2]];
}

const colorCircles = document.getElementsByClassName('color-circle');
for (let i = 0; i < colorCircles.length; i++) {
    colorCircles[i].addEventListener('click', function (event) {
        const rgbColor = getComputedStyle(event.target).backgroundColor;
        const colorValues = rgbColor.match(/\d+/g);
        currentColor = [
            parseInt(colorValues[0]),
            parseInt(colorValues[1]),
            parseInt(colorValues[2])
        ];
    });
}

canvas.onclick = function (event) {
    if (isFilling) {
        return;
    }

    const clickX = event.pageX - canvas.offsetLeft;
    const clickY = event.pageY - canvas.offsetTop;
    const clickedPixel = canvasContext.getImageData(clickX, clickY, 1, 1);
    const clickedColor = clickedPixel.data;
   
    if (clickedColor[0] === 0 && clickedColor[1] === 0 && clickedColor[2] === 0 && clickedColor[3] === 255) {
        return;
    }
    
    isFilling = true;
    
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const canvasData = canvasContext.getImageData(0, 0, canvasWidth, canvasHeight);
    
    const { palette, pixels } = compressImageData(canvasData, canvasWidth, canvasHeight);
    
    const requestData = {
        width: canvasWidth,
        height: canvasHeight,
        palette,
        pixels,
        fill_color: currentColor,
        position: {
            row: event.offsetY,
            col: event.offsetX
        }
    };
    
    axios.post('/fill', requestData, {
        headers: {
            'Content-Type': 'application/json'
        }
    }).then((response) => {
        const responseData = response.data;
        const newImageData = decompressImageData(responseData, canvasWidth, canvasHeight);
        canvasContext.putImageData(newImageData, 0, 0);
        isFilling = false;
    }).catch((error) => {
        console.error('填色失败:', error);
        isFilling = false;
    });
}

$('.back').click(function () {
    $('.choose-pic').css('display', 'flex')
    $('.control').css('display', 'none')
    canvasContext.clearRect(0, 0, canvas.width, canvas.height);
    sourceImageUrl = '';
    sourceImage.src = '';
});