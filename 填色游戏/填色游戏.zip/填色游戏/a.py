# 创建判断功能
def is_legal(img, row, col, color):
    if 0 <= row <= len(img)-1 and 0 <= col <= len(img[0])-1:
        if img[row][col] != [0, 0, 0] and img[row][col] != color:
            return True

# 填色功能
def bfs(img, target, color):
    # 获取位置
    row = target[0]
    col = target[1]
    # 新建通知队列
    q = []
    # 判断该点是否可以填色
    if is_legal(img, row, col, color):
        # 改变对应位置上的颜色并加入通知队列
        img[row][col] = color
        q.append([row, col])
    while len(q) != 0:
        current = q.pop(0)
        row = current[0]
        col = current[1]
        # 判断上方是否可以填色
        if is_legal(img, row - 1, col, color):
            # 改变对应位置上的颜色并加入通知队列
            img[row - 1][col] = color
            q.append([row - 1, col])
        # 判断下方是否可以填色
        if is_legal(img, row + 1, col, color):
            # 改变对应位置上的颜色并加入通知队列
            img[row + 1][col] = color
            q.append([row + 1, col])
        # 判断左边是否可以填色
        if is_legal(img, row, col - 1, color):
            # 改变对应位置上的颜色并加入通知队列
            img[row][col - 1] = color
            q.append([row, col - 1])
        # 判断右边是否可以填色
        if is_legal(img, row, col + 1, color):
            # 改变对应位置上的颜色并加入通知队列
            img[row][col + 1] = color
            q.append([row, col + 1])
    # 返回修改后的图片信息
    return img
