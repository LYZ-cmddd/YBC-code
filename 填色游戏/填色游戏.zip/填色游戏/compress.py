def decompress_image(data):
    width = data['width']
    height = data['height']
    palette = data['palette']
    imgArr = [[None] * width for _ in range(height)]
    
    current_pos = 0
    for color_idx, count in data['pixels']:
        row = current_pos // width
        col = current_pos % width
        
        while count > 0 and col < width:
            imgArr[row][col] = palette[color_idx]
            count -= 1
            current_pos += 1
            col += 1
        
        while count > 0:
            row = current_pos // width
            col = current_pos % width
            imgArr[row][col] = palette[color_idx]
            count -= 1
            current_pos += 1
    
    data['imgArr'] = imgArr
    data['palette'] = palette
    
    return data

def compress_image(image_array, palette, fill_color):
    if fill_color not in palette:
        palette.append(fill_color)
    color_to_idx = {tuple(color): idx for idx, color in enumerate(palette)}
    compressed = []
    height = len(image_array)
    width = len(image_array[0])
    
    first_color = tuple(image_array[0][0])
    current_index = color_to_idx[first_color]
    count = 1
    
    for y in range(height):
        for x in range(width):
            if y == 0 and x == 0:
                continue
            
            color = tuple(image_array[y][x])
            color_idx = color_to_idx[color]
            
            if color_idx == current_index:
                count += 1
            else:
                compressed.append([current_index, count])
                current_index = color_idx
                count = 1
    
    compressed.append([current_index, count])
    
    result = {
        'palette': palette,
        'pixels': compressed
    }
    
    return result
