import json
import time
from flask import Flask, render_template, request, jsonify
from a import *
from compress import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/fill', methods=['post'])
def fill():
    data = decompress_image(request.json)
    
    target = data['position']
    row = target['row']
    col = target['col']
    target = (row, col)
    fill_color = data['fill_color']
    
    res = bfs(data['imgArr'], target, fill_color)
    
    return jsonify(compress_image(res, palette=data['palette'], fill_color=fill_color))

app.run(port=10003,debug=1)