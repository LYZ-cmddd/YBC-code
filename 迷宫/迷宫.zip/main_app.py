from flask import Flask, render_template, request, jsonify
from a import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/path/', methods=['POST'])
def find_path():
    """返回迷宫出路坐标列表"""
    maze = request.form.get('maze')
    start = request.form.get('start')
    end = request.form.get('end')

    maze = eval(maze)
    start = eval(start)
    end = eval(end)

    paths = dfs_maze(maze, start, end)

    return jsonify(paths)


app.run(port=10001)