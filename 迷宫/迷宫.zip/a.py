# 深度优先搜索算法-全部路径
def dfs_maze(maze, start, end):
    # 走过位置的列表
    visited = []
    current = start
    visited.append(current)
    # 创建一个栈保存正确的路线
    path = []
    # 将开始位置加入到栈中
    path.append(current)
    while True:
        if current == end:
            return path
        # 获取当前位置行列
        row = current[0]
        col = current[1]
        # 选择一个方向移动
        # 判断是否可以向上移动
        if maze[row-1][col] == 1 and [row-1, col] not in visited:
            # 向上移动，改变当前位置并记录
            current = [row-1, col]
            visited.append(current)
            path.append(current)
        # 判断是否可以向下移动
        elif maze[row+1][col] == 1 and [row+1, col] not in visited:
            # 向下移动，改变当前位置并记录
            current = [row+1, col]
            visited.append(current)
            path.append(current)
        # 判断是否可以向左移动
        elif maze[row][col-1] == 1 and [row, col-1] not in visited:
            # 向左移动，改变当前位置并记录
            current = [row, col-1]
            visited.append(current)
            path.append(current)
        # 判断是否可以向右移动
        elif maze[row][col+1] == 1 and [row, col+1] not in visited:
            # 向右移动，改变当前位置并记录
            current = [row, col+1]
            visited.append(current)
            path.append(current)
        else:
            path.pop()
            current = path[-1]