function randint(m, n) {
    return m + Math.floor(Math.random() * (n - m));
}
function shuffle(arr) {
    let newArr = Array.from(arr);
    for (let i = 1; i < newArr.length; i++) {
        const random = randint(0, i + 1);
        [newArr[i], newArr[random]] = [newArr[random], newArr[i]];
    }
    return newArr;
}
// 0：墙，1：路（用于迷宫固定时）
const PATHS = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0],
    [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0],
    [0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    [0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    [0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0],
    [0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0],
    [0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0],
    [0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    [0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0],
    [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
    [0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0],
    [0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
];
// 起始点（用于迷宫固定时）
const START = { row: 1, col: 10 };
// 终点（用于迷宫固定时）
const END = { row: 11, col: 17 };

// 方向
const DIRECTION = [1, 2, 3, 4];
// 每个方向计算行列序号时的偏移量
const DIRECTION_OFFSET = {
    1: [-1, 0],
    2: [1, 0],
    3: [0, -1],
    4: [0, 1]
}

/**
 * 生成迷宫线路，使用prim算法，0：墙，1：路
 * @param {Array} roads 路，二维列表，0：表示为访问过，1：表示已访问 
 * @param {Number} startRow 开始生成线路的起点，路列表的行序号 
 * @param {Number} startCol 列序号
 * @param {Number} maxRow 路列表的最大行序号
 * @param {Number} maxCol 路列表的最大列序号
 * @param {Array} maze 迷宫列表，二维列表
 */
function _generateMaze(roads, startRow, startCol, maxRow, maxCol, maze) {
    roads[startRow][startCol] = 1;
    let direction = shuffle(DIRECTION);
    let d, offset, newRow, newCol, mazeRow, mazeCol;
    for (d of direction) {
        offset = DIRECTION_OFFSET[d];
        newRow = startRow + offset[0];
        newCol = startCol + offset[1];
        if (newRow < 0 || newRow > maxRow || newCol < 0 || newCol > maxCol) {
            continue;
        }

        if (roads[newRow][newCol] === 1) {
            continue;
        }

        mazeRow = 2 * startRow + 1;
        mazeCol = 2 * startCol + 1;

        maze[mazeRow + offset[0]][mazeCol + offset[1]] = 1;
        _generateMaze(roads, newRow, newCol, maxRow, maxCol, maze);
    }
}

/**
 * 
 * @param {Number} rowNum 迷宫中路的行数，迷宫实际大小为2 * n + 1
 * @param {Number} colNum 迷宫中路的列数，迷宫实际大小为2 * n + 1
 * @returns {Object} 迷宫数据
 */
function generateMaze(rowNum, colNum) {
    // if (rowNum > 30 || rowNum < 10) {
    //     throw "行数超出范围，需在10~30";
    // }
    // if (colNum > 20 || colNum < 10) {
    //     throw "行数超出范围，需在10~20";
    // }

    let mazeRowNum = 2 * rowNum + 1;
    let mazeColNum = 2 * colNum + 1;

    let roads = [];
    for (let i = 0; i < rowNum; i++) {
        roads.push(new Array(colNum).fill(0));
    }

    let maze = [];
    for (let i = 0; i < mazeRowNum; i++) {
        maze.push(new Array(mazeColNum).fill(1));
    }

    for (let i = 0; i < mazeRowNum; i++) {
        if (i % 2 === 0) {
            for (let j = 0; j < mazeColNum; j++) {
                maze[i][j] = 0;
            }
        }
    }

    for (let i = 0; i < mazeColNum; i++) {
        if (i % 2 === 0) {
            for (let j = 0; j < mazeRowNum; j++) {
                maze[j][i] = 0;
            }
        }
    }

    _generateMaze(roads, 0, 0, rowNum - 1, colNum - 1, maze);

    // 存储迷宫中所有能作为起点和终点的行列号
    let position = [];
    for (let i = 0; i < maze.length; i++) {
        for (let j = 0; j < maze[i].length; j++) {
            if (maze[i][j] === 1) {
                position.push([i, j]);
            }
        }
    }
    // 随机选取起点和终点
    let point1 = randint(1, position.length);
    let point2 = randint(1, position.length);
    while (point1 === point2) {
        point2 = randint(1, position.length);
    }

    return {
        start: { // 起点
            row: position[point1][0],
            col: position[point1][1]
        },
        end: { // 终点
            row: position[point2][0],
            col: position[point2][1]
        },
        paths: maze // 迷宫数据，二维列表
    }
}

/**
 * 绘制迷宫
 * @param {Phaser.GameObjects.RenderTexture} renderTexture 精灵
 * @param {Array} paths 路径信息，同常量PATHS格式 
 * @param {Number} cellWidth 一块路径（格子）宽 
 * @param {Number} cellHeight 一块路径（格子）高
 * @param {String} texture 纹理 
 * @param {String} frame 帧
 */
function drawMaze(renderTexture, paths, cellWidth, cellHeight, texture, frame) {
    let i, j, row;
    renderTexture.beginDraw();
    for (i = 0; i < paths.length; i++) {
        row = paths[i];
        for (j = 0; j < row.length; j++) {
            if (row[j] === 0) {
                renderTexture.batchDrawFrame(texture, frame, cellWidth * j, cellHeight * i);
            }
        }
    }
    renderTexture.endDraw();
}

/**
 * 检测终点
 * @param {Number} row 当前行序号
 * @param {Number} col 当前列序号
 * @param {Number} endRow 终点行序号
 * @param {Number} endCol 终点列序号
 * @returns {Boolean} 在终点则返回true，否则false
 */
function checkEnd(row, col, endRow, endCol) {
    if (row === endRow && col === endCol) {
        return true;
    }
    return false;
}

/**
 * 检测路径能否移动
 * @param {Array} paths 路径信息，同PATHS格式 
 * @param {Number} row 当前行序号
 * @param {Number} col 当前列序号
 * @param {Number} direction 要移动的方向，1上2下3左4右
 * @returns  {Boolean} 可移动则返回true，否则false
 */
function checkPath(paths, row, col, direction) {
    let offset = DIRECTION_OFFSET[direction];
    let newRow = row + offset[0];
    let newCol = col + offset[1];
    return paths[newRow][newCol] === 1 ? [newRow, newCol] : false;
}
/**
 * 计算可移动的路径
 * @param {Array} paths 路径信息，同PATHS格式 
 * @param {Number} row 当前行序号
 * @param {Number} col 当前列序号
 * @param {Number} endRow 终点行序号
 * @param {Number} endCol 终点列序号
 * @param {Array} directions 要移动的方向数组，1上2下3左4右
 * @returns {Array} 可移动的路径数组，格式：[{row: 1, col: 1}, ...]
 */
function calculatePaths(paths, row, col, endRow, endCol, directions) {
    let dir,
        result,
        movablePaths = [];
    for (dir of directions) {
        result = checkPath(paths, row, col, dir);
        if (result) {
            [row, col] = result;
            movablePaths.push({
                row,
                col,
            });

            if (checkEnd(row, col, endRow, endCol)) {
                break;
            }
        } else {
            break;
        }
    }
    return movablePaths;
}