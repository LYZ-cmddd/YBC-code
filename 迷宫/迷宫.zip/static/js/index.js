window.onload = function () {
    vm = new Vue({
        el: '#app',
        data: {
            covers: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
            paths: [],
            start: [],
            initStart: [],
            end: [],
            auto: false,
            gameOver: false,  // 游戏结束
            showChart: false, // 是否点击游戏开始按钮
            randomRaw: 21, // 迷宫的行数，需不小于5，最大21，为奇数行
            randomCol: 21, // 迷宫的列数，需不小于5，最大21，为奇数列
            mode: 'random', // random是随机迷宫(更改randomRaw和randomCol)，sample1是样例1，sample2是样例2，sample3是样例3
            sample1: {
                paths: [
                    [0, 0, 0],
                    [0, 1, 0],
                    [0, 1, 0],
                    [0, 0, 0],
                ],
                start: {row: 2, col: 1},
                end: {row: 1, col: 1},
            },
            sample2: {
                paths: [
                    [0, 0, 0],
                    [0, 1, 0],
                    [0, 1, 0],
                    [0, 1, 0],
                    [0, 1, 0],
                    [0, 0, 0],
                ],
                start: {row: 4, col: 1},
                end: {row: 1, col: 1},
            },
            sample3: {
                paths: [
                    [0, 0, 0, 0, 0],
                    [0, 1, 1, 1, 0],
                    [0, 0, 0, 1, 0],
                    [0, 1, 0, 1, 0],
                    [0, 1, 1, 1, 0],
                    [0, 0, 0, 0, 0],
                ],
                start: {row: 3, col: 1},
                end: {row: 1, col: 1},
            },
            sample4: {
                paths: [
                    [0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0],
                    [0, 1, 1, 1, 0],
                    [0, 0, 0, 1, 0],
                    [0, 1, 0, 1, 0],
                    [0, 1, 1, 1, 0],
                    [0, 0, 0, 0, 0],
                ],
                start: {row: 4, col: 1},
                end: {row: 2, col: 1},
            },
        },
        computed: {
            raw () {
                if (this.mode == 'sample1') {
                    return 4
                } else if (this.mode == 'sample2') {
                    return 6
                } else if (this.mode == 'sample3') {
                    return 6
                } else if (this.mode == 'sample4') {
                    return 7
                } else {
                    return this.randomRaw
                }
            },
            col () {
                if (this.mode == 'sample1') {
                    return 3
                } else if (this.mode == 'sample2') {
                    return 3
                } else if (this.mode == 'sample3') {
                    return 5
                } else if (this.mode == 'sample4') {
                    return 5
                } else {
                    return this.randomCol
                }
            },
            detaX () {
                if (this.mode == 'sample1') {
                    return 9
                } else if (this.mode == 'sample2') {
                    return 8
                } else if (this.mode == 'sample3') {
                    return 8
                } else if (this.mode == 'sample4') {
                    return 7
                } else {
                    return ((21-this.randomRaw) / 2)
                }
            },
            detaY () {
                if (this.mode == 'sample1') {
                    return 9
                } else if (this.mode == 'sample2') {
                    return 9
                } else if (this.mode == 'sample3') {
                    return 8
                } else if (this.mode == 'sample4') {
                    return 8
                } else {
                    return ((21-this.randomCol) / 2)
                }
            },
        },
        mounted () {
            window.addEventListener('keydown', this.keyDownHandler);
            this.init();
        },
        methods: {
            autoStart () {
                if (this.auto) {
                    return;
                };
                this.auto = true;
                this.$nextTick(() => {
                    this.getCorrPath().then(paths => {
                        let index = 0;
                        let timer = setInterval(() => {
                            this.start = paths[index];
                            if (this.start[0] == this.end[0] && this.start[1] == this.end[1]) {
                                this.gameOver = true;
                                clearInterval(timer);
                                timer = null;
                                setTimeout(() => {
                                    alert("已找到");
                                    this.restart();
                                }, 300);
                                return
                            }
                            index++;
                        }, 200)
                    }).catch(() => {})
                })
            },
            keyDownHandler (e) {
                if (this.auto) {
                    return;
                }
                let keyCode = e.which || e.keyCode;
                switch (keyCode) {
                    case 37: { // Left
                        if (e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) {
                            break;
                        }
                        e.preventDefault();
                        let [x, y] = this.start;
                        if (this.paths[x][y-1] && this.paths[x][y-1] == 1) {
                            this.start = [x, y-1];
                        }
                        break;
                    }
                    case 39: { //Right
                        if (e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) {
                            break;
                        }
                        e.preventDefault();
                        let [x, y] = this.start;
                        if (this.paths[x][y+1] && this.paths[x][y+1] == 1) {
                            this.start = [x, y+1];
                        }
                        break;
                    }
                    case 38: { // Top
                        if (e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) {
                            break;
                        }
                        e.preventDefault();
                        let [x, y] = this.start;
                        if (this.paths[x-1][y] && this.paths[x-1][y] == 1) {
                            this.start = [x-1, y];
                        }
                        break;
                    }
                    case 40: { // Bottom
                        if (e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) {
                            break;
                        }
                        e.preventDefault();
                        let [x, y] = this.start;
                        if (this.paths[x+1][y] && this.paths[x+1][y] == 1) {
                            this.start = [x+1, y];
                        }
                        break;
                    }
                }
                if (this.start[0] == this.end[0] && this.start[1] == this.end[1]) {
                    this.gameOver = true;
                    setTimeout(() => {
                        alert("已找到");
                        this.restart();
                    }, 300);
                    return
                }
            },
            getCorrPath () {
                return new Promise((resolve, reject) => {
                    var form = new FormData();
                    form.append("maze", JSON.stringify(this.paths));
                    form.append("start", JSON.stringify(this.initStart));
                    form.append("end", JSON.stringify(this.end));
                    var settings = {
                        "url": "/api/path/",
                        // "url": "https://show.ybccode.com/maze/api/path/",
                        "method": "POST",
                        "timeout": 0,
                        "headers": {},
                        "processData": false,
                        "mimeType": "multipart/form-data",
                        "contentType": false,
                        "data": form
                    };
                    $.ajax(settings).done((response) => {
                        let res= JSON.parse(response);
                        if (res.length) {
                            resolve(res)
                        }
                        // console.log('res',res)
                        /* if (res.code == 200 && res.result && res.result.paths.length) {
                            resolve(res.result.paths);
                        } */
                        if (res && res.length) {
                            resolve(res);
                        }
                        reject('error');
                    }).fail(() => {
                        reject('error');
                    });
                });
            },
            init () {
                let datas = {};
                if (this.mode == 'sample1') {
                    datas = this.sample1
                } else if (this.mode == 'sample2') {
                    datas = this.sample2
                } else if (this.mode == 'sample3') {
                    datas = this.sample3
                } else if (this.mode == 'sample4') {
                    datas = this.sample4
                } else {
                    datas = generateMaze((this.randomRaw - 1) / 2, (this.randomCol - 1) / 2);
                }
                let paths = datas.paths;
                let start = datas.start;
                let end = datas.end;
                
                this.paths = paths;
                this.start = [start.row, start.col];
                this.initStart = [start.row, start.col];
                this.end = [end.row, end.col];
                this.auto = false;
                this.showChart = true;
                console.log(this.paths)
                console.log(this.start)
                console.log(this.end)
            },
            // startGame () {
            //     if (!this.showChart) {
            //         this.init();
            //     }
            // },
            getCoverClass(x, y) {
                return {
                    'palette-cell': true,
                    // 'hasImg': (this.start[0] == (x-((21-this.raw)/2)) && this.start[1] == (y-((21-this.col)/2))) ? false : true,
                    // 'hasImg': ((x < ((21-this.raw)/2)) || (x >= (((21-this.raw)/2) + this.raw)) || (y < ((21-this.col)/2)) || (y >= ((21-this.col)/2 + this.col))) ? true : false,
                    'hasImg': ((x < this.detaX) || (x >= (this.detaX + this.raw)) || (y < this.detaY) || (y >= (this.detaY + this.col))) ? true : false,
                }
            }, // 3 6  8 11
            getClass(x, y, value) {
                return {
                    'palette-cell': true,
                    'bg1': (x+y)%2 == 0 ? true: false,
                    'bg2': (x+y)%2 == 0 ? false: true,
                    'hasImg': value == 0,
                    end: this.end[0] == x && this.end[1] == y,
                    start: this.start[0] == x && this.start[1] == y
                }
            },
            // getStartClass () {
            //     return {
            //         'start-img': true,
            //         'ready': this.showChart
            //     }
            // },
            getAutoClass () {
                return {
                    'auto-start': true,
                    'auto': this.auto
                }
            },
            restart () {
                if (this.gameOver) {
                    this.gameOver = false;
                    this.showChart = false;
                    this.auto = false;
                    this.init()
                }
            }
        },
        beforeDestroy() {
            window.removeEventListener('keydown', this.keyDownHandler);
        }
    })
}