var file = document.getElementById('file');
var image = document.getElementById("upload_img");
file.onchange = function() {
  var fileData = this.files[0];//获取到一个FileList对象中的第一个文件( File 对象),是我们上传的文件
  var reader = new FileReader();
  reader.readAsDataURL(fileData);//异步读取文件内容，结果用data:url的字符串形式表示
  /*当读取操作成功完成时调用*/
  reader.onload = function(e) {
      image && image.setAttribute("src", this.result)
      image.setAttribute("style", "width: 100% ;height: 100%")
  }
}