from flask import Flask, render_template, request
from ybc_assistant import personal_show

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/show', methods=['post'])
def show():
    # 获取姓名
    user = request.form['user']
    # 获取性别
    gender = request.form['gender']
    # 获取年龄
    age = request.form['age']
    # 获取邮箱
    email = request.form['email']
    # 获取学校
    school = request.form['school']
    # 获取风格
    style = request.form['style']
    # 获取简介
    intro = request.form['intro']
    # 获取爱好
    hobby = request.form.getlist('hobby')
    # 获取图片
    pic = request.files['pic']

    # 定义字典
    info = {
        'user': user,
        'gender': gender,
        'age': age,
        'email': email,
        'school': school,
        'style': style,
        'hobby': hobby,
        'intro': intro,
        'pic': pic
    }
    # 任务二：调用personal_show.generate()功能生成名片，参数为字典info
    imgs = personal_show.generate(info)
    print(imgs)

    return render_template('show.html', imgs = imgs)


app.run(port=5001)
