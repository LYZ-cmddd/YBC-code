from flask import Flask, render_template, request

# 要调用的模块
from ybc_assistant import image_master


app = Flask(__name__)


@app.route('/')
def index():
    """提交个人信息"""
    return render_template('index.html')


@app.route('/download', methods=['post'])
def download():
    # 获取姓名
    user = request.form['user']
    # 获取性别
    gender = request.form['gender']
    # 获取风格
    style = request.form['style']
    # 获取背景
    bg = request.form['bg']

    data = {
        'user': user,
        'gender': gender,
        'style': style,
        'bg': bg
    }
    print(data)

    # 要调用的模块
    info = image_master.generate(data)
    print(info)

    return render_template('download.html', info=info)


app.run(port=5001)
